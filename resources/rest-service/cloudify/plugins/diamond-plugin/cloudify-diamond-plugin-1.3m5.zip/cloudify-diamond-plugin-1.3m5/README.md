# Cloudify Diamond Plugin

* Master Branch [![Build Status](https://travis-ci.org/cloudify-cosmo/cloudify-diamond-plugin.svg?branch=master)](https://travis-ci.org/cloudify-cosmo/cloudify-diamond-plugin)
* PyPI [![PyPI](http://img.shields.io/pypi/dm/cloudify-diamond-plugin.svg)](http://img.shields.io/pypi/dm/cloudify-diamond-plugin.svg)
* Version [![PypI](http://img.shields.io/pypi/v/cloudify-diamond-plugin.svg)](http://img.shields.io/pypi/v/cloudify-diamond-plugin.svg)

Cloudify [Diamond](https://github.com/BrightcoveOS/Diamond) monitoring plugin.

See [Diamond Plugin](http://getcloudify.org/guide/plugin-diamond.html)

