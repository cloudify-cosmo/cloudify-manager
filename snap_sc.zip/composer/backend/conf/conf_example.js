/**
 * this is an example file for configuration. we chose js to support comments
 *
 * your file should be named me.json and not include 'var conf' at the beginning and ';' at the end or any comments
 **/


var conf = {
    'db': {'mongo':'mongodb://127.0.0.1:27017/composer','nedb':'nedb-data'},
    'sessionSecret': 'blueprint-composer-secret', // some random string to be used when encrypting cookies
    'dslParser': { // optional. if does not exist, will use mock implementation.
        'virtualenv': 'absolute-path-to-virtualenv-basedir', // location to virtualenv with dsl-parser-cli command available
    },
    "managerConfig":{
        "ip": "10.239.1.8", // cloudify manager IP
        "port": "80", // cloudify manager API port
        "protocol": "http://", // protocol, either http:// or https://
        "version": "v3.1", // API version
        "ca" : "" // path to CA cert, or blank string if not applicable
      }
};


