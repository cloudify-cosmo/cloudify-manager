#!/bin/bash

set -e

ctx logger info "Installing gunicorn"
pip install gunicorn
