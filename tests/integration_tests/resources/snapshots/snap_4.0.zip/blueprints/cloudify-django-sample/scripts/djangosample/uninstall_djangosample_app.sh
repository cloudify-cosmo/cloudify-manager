#!/bin/bash

set -e

TEMP_DIR='/tmp'
rm ${TEMP_DIR}/master.tar.gz

ROOT_PATH=~/djangosample
rm -fr ${ROOT_PATH}