#!/bin/bash

set -e

ctx logger info "Going to uninstall Django"
pip uninstall -y Django