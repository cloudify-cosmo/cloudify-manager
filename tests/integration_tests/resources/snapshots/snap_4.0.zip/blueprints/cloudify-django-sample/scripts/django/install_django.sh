#!/bin/bash

set -e

ctx logger info "Going to install Django"

set +e
yum_cmd=$(which yum 2> /dev/null)
set -e

if [[ ! -z ${yum_cmd} ]]; then
    sudo yum install -y -q epel-release
    sudo yum install -y -q Django==1.9.7

    #git clone git://github.com/django/django.git
    #bin/python django/setup.py install
else
    pip install Django==1.9.7
fi
