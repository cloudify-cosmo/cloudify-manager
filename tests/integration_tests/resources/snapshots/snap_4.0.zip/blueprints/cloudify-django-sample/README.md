# About
Simple blueprint that includes Django with Gunicorn and Nginx